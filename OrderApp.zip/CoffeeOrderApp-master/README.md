# CoffeeOrderApp
Hi Everyone. This app has 
Recylerview displaying coffee Images, and description. And then each view (of main activity) is clickable and can have its own activity.
I have only added activities for position 0 and 1 and rest if someone wants to do they can. 
I have also used SQLiteDatabase to save the orders from all activities and keep their information in the orderSummary. So no matter you exit the app or the exit and choose to order 
different drink. Your previous order info will remain unless you clear the databse (I have provided the button for that) 
Any questions dev.samakram@gmail.com

The main Highlight of this App is the CART AND ITS ABILITY to hold the data.
